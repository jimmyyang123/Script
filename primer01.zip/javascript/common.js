<!--
function redirect()
{
/*
 * Find the search part of the string. The idea is that we can use HTML links of the form
 *
 * a/file?c=file1.html#pos1+l=file2.html#pos2+m=file3.html#pos3 ...
 *
 * Which will load the file 'file1.html' at position 'pos1' into the frame 'c'
 *                          'file2.html' at position 'pos2' into the frame 'l'
 * etc. We cannot use location.search as this would only give the string from '?'
 * up to the first '#'. Instead search for the first '?' in the string and take 
 * everything from that.
 */
    var query = location.href;			// Load the entire location string into query
    var qpos  = query.indexOf('?');		// Find the position of the '?' character
    if (qpos == -1)
    {
        return;
    }
    else
        var string= query.substring(qpos+1);	// Take everything after the '?'

    var pairs = string.split("+");		// split string at '+' into 'label=something' pair
    for (var i=0; i<pairs.length; i++)
    {
        var pos = pairs[i].indexOf('=');	// Find position of '=' in pair
        if (pos == -1) continue;		// No '=' so skip this pair
	var name  = pairs[i].substring(0,pos);	// Extract name from pair
	var value = pairs[i].substring(pos+1);	// Extract value from pair
        window.parent.frames[name].location.href = value;

        if (name == 'm')
        {
            var xID = value;
            xID = xID.replace(/\s+/g, "");
            xID = xID.replace(/['"\^]/g, "");
            xID = xID.replace(/\.htm/, "");
            xID = xID.replace(/^.*\//, "");

            find_in_tree(xID);
        }
    }
}

function find_in_tree(name)
{
// Finds the node called 'name' in the tree and makes sure that it is expanded and scrolled to

    var folderObj;

// First look for an exact match
    folderObj = parent.c.findObj(name);

// If one isn't found then look for the first ID that starts with this
    if (folderObj == null)
    {
        folderObj = parent.c.findObjMatch(name);
    }

// If one still isn't found then give up
    if (folderObj == null) return;

    folderObj.forceOpeningOfAncestorFolders();
    if (!folderObj.isOpen)
        parent.c.clickOnNodeObj(folderObj);

}
// -->
