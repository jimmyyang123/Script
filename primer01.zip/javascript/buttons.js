<!--
function update_contents_detail(detail)
{
/*
 * Update the detail of the contents page shown
 *
 * What is the page that is actually loaded in the contents window at present?
 */
    var contents = window.parent.frames.l.location.pathname;

/*
 * Find the current number and detail
 */
    var result = contents.match(/_(\d+)_detail_(\d)/)
    if (result != null)
    {
        current_number = result[1];
        current_detail = result[2];

/* Now if the contents detail is different to the current one update the page */

        if (detail != current_detail)
        {
            window.parent.frames.l.location = '../navigation/contents_'+ current_number + '_detail_' + detail + '.htm';
        }
    }
}

function printpage()
{
    if (window.print)
    {
        window.parent.frames.m.focus();
        window.parent.frames.m.print();
    }
    else
        alert("Sorry, your browser does not support this. Please upgrade to a newer browser");
}

function top_of_page()
{
    window.parent.frames.m.location.hash="top";
}

function bottom_of_page()
{
    window.parent.frames.m.location.hash="bottom";
}

function exit_help()
{
    if (window.parent.close)
	    window.parent.close();
   else
        alert("Sorry, your browser does not support this. Please upgrade to a newer browser");
}

function break_out_of_frames()
{
/* Check to see if we are in a frame if we are then break out of it */
    window.parent.location.href = window.parent.frames.m.location.href;
}

function do_search(search_text)
{
    if ( (search_text == null) || (search_text == "") || isblank(search_text) )
    {
        alert('You have not entered a search string. Please enter one in the text box and try again\n');
    }
    else
    {
/*      alert("The search text you entered is " + search_text + "\n" +
 *           "Opening new window...\n");
 */
	search_win = window.open("../search/search_index.htm?" + encodeURIComponent(search_text),
                                 "s", 
                                 "alwaysRaised=yes,toolbar=no,status=no,menubar=no,width=480,height=320,scrollbars=yes");
/*      alert("Opened window\n" +
 *            "Form value is now\n" + window.document.searchbox.searchtext.value + "\n");
 */
    }
}

function isblank(s)
{
    for (var i=0; i<s.length; i++)
	{
	    var c = s.charAt(i);
		if ( (c!= ' ') && (c!='\t') ) return false;
	}
	return true;
}

function do_search_2()
{
    var search_string = window.location.search.substr(1);

/* Now go through all the links in the document and write a new document with
 * all the links that match the search string
 */
    var search_regexp = new RegExp(search_string, "i");

/*  alert("Doing search for " + search_regexp + "\n" +
 *        "There are " + document.links.length + " links\n"); 
 */
    var search_links = new Array();
    var search_text  = new Array();
    var nmatch = 0;

    var browser = browser_type();

    for (var i=0; i<document.links.length; i++)
    {	 

        if ( (browser == "netscape") || (browser == "mozilla"))
        {
/*          alert("Checking link " + i + " of " + document.links.length + "\n" +
 *                "Link text=" + document.links[i].text + "\n" +
 *                "Link href=" + document.links[i].href + "\n")   
 */
            if (document.links[i].text != null)
            {
                var result = document.links[i].text.match(search_regexp);
                if (result != null)
                {
/*                  alert("Match found!\n" + 
 *                        "Link text=" + document.links[i].text + "\n" +
 *                        "Link href=" + document.links[i].href + "\n");
 */
                    nmatch++;
                    search_links[nmatch] = document.links[i].href;
                    search_text[nmatch]  = document.links[i].text;
                }
            }
        }
        else if (browser == "ie")
        {
/*          alert("Checking link " + i + " of " + document.links.length + "\n" +
 *                "Link text=" + document.links[i].innerText + "\n" +
 *                "Link href=" + document.links[i].href + "\n")   
 */
            if (document.links[i].innerText != null)
            {
                var result = document.links[i].innerText.match(search_regexp);
                if (result != null)
                {
/*                  alert("Match found!\n" + 
 *                        "Link text=" + document.links[i].innerText + "\n" +
 *                        "Link href=" + document.links[i].href + "\n");
 */
                    nmatch++;
                    search_links[nmatch] = document.links[i].href;
                    search_text[nmatch]  = document.links[i].innerText;
                }
            }

        }
    }
	
/* Now we have all the links, display a page with all of the links in */
    
/*  alert("Finished search. Displaying results\n"); */

    document.write('<HTML>');
    document.write('<HEAD>');
    document.write('<TITLE>Search</TITLE>');
    document.write('<link rel="stylesheet" href="../stylesheets/search.css" type="text/css">');
    document.write('</HEAD>');
    document.write('<BODY>');

    if (nmatch > 0)
    {
        if (nmatch > 1) { var multiple = 'es'; }
        else            { var multiple = ''; }
        document.write('<P>' + nmatch + ' match' + multiple + 
                                               ' found for search &quot;' +
                                               search_string + '&quot;.</P>');

        document.write('<ul>');
        for (var i=1; i<=nmatch; i++)
        {
            document.write('<li><A HREF="' + search_links[i] + '" TARGET="m">' + search_text[i] + '</A>');
        }
        document.write('</ul>');
    }
    else
    {
        document.write('<P></P>');
        document.write('<P>Sorry, No links could be found that match your search. Please try again</P>');
    }
    document.write('</BODY>');
    document.write('</HTML>');
    document.close();

    if (browser != "mozilla") window.focus();
}

function browser_type()
{
    if (document.all)
        var browser = "ie";
    else if (document.layers)
        browser = "netscape";
    else if (document.getElementById)
        browser = "mozilla";
    else
        browser = "unknown";

/*  alert("Browser type " + browser + " detected\n"); */

    return browser;
}
// -->
