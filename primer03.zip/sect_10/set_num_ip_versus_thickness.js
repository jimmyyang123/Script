// Get the model object for model 1
var m = Model.GetFromID(1);

// Get the first section card in the model
var s = Section.First(m);

// While there is a section card look at it
while (s)
{
// If this section card is a section shell type and it exists then look at it
    if (s.type == Section.SHELL && s.exists)
    {
// If thickness is < 1 then assign 2 ipts, < 2 assign 3 ipts, otherwise 5 ipts
        if      (s.t1 < 1.0) s.nip = 2;
        else if (s.t1 < 2.0) s.nip = 3;
        else                 s.nip = 5;
    }

// Get the next section after this one
    s = s.Next();
}
