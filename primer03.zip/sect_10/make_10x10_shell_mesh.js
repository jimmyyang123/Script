// Declare variables
var x, y, i, j;

// Create a new model
var m = new Model();

// Give message saying what we are doing
Message("Making nodes");

// Loop over y nodes
for (y=0; y<11; y++)
{
// Loop over x nodes
    for (x=0; x<11; x++)
    {
// make node in model m
        var n = new Node(m, 1+x+(y*11), x*10, y*10, 0);
    }
}

Message("Making shells");
for (i=1; i<=10; i++)
{
    for (j=1; j<=10; j++)
    {
// Make shell
        var s = new Shell(m, i+(j*10), 1, ((i-1)*11)+j+0, ((i-1)*11)+j+1,
                                          ((i-0)*11)+j+1, ((i-0)*11)+j+0);
    }
}

// Update the graphics in model
m.UpdateGraphics();

// View XY plane
View.Show(View.XY);

// Autoscale view
View.Ac();
